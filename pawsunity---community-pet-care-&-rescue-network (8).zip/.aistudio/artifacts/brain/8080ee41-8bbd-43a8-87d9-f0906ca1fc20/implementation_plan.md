# PawsCause: Premium Pet-Tech Design System Transformation

Transform the entire aesthetic of the 6-module PawsCause web application into a warm, modern, and compassionate pet-tech design system using Terracotta (#E05A47), Forest Mint (#2D6A4F), and Warm Cream (#FAF7F2), strictly preserving all underlying DOM IDs, class names, and JavaScript storage logic.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> **Confirmed Design System Directives**:
> - **Primary Brand (Warmth & Compassion)**: Terracotta / Warm Coral (`#E05A47`, with hover `#C84B3A` and accent `#EE6C4D`) for all primary action buttons, active navigation tabs, range sliders, and key focus rings.
> - **Secondary / Success (Trust & Vitality)**: Forest Mint / Sage Green (`#2D6A4F` deep, `#52B788` bright, `#E8F5EE` tint) for verified badges, government licenses, and success notifications.
> - **Canvas / Background**: Off-White Warm Cream (`--bg-base: #FAF7F2`) replacing the cold generic `#f8fafc`.
> - **Surfaces & Cards**: Crisp Pure White (`#FFFFFF`) with subtle soft depth (`box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05)` and hairline borders `rgba(0, 0, 0, 0.06)`).
> - **Typography & Headlines**: Dark Slate Grey (`#1E293B`) completely replacing pure black (`#000000`) for high-contrast yet soft, editorial readability.
> - **Hero Banners**: Soft linear gradients combining pastel tints of Warm Coral and Forest Mint across all 6 modules.
> - **Zero Logic Mutation**: JavaScript `mockApiHandler`, IndexedDB/localStorage persistence, and element IDs remain 100% untouched.

---

## 1. Overview & Core Concept

- **What It Does**: Upgrades the entire visual layer of PawsCause—including the header, live status bar, tab switcher, input forms, and 6 specialized module interfaces (Pet Registration, Stray Dog Triage, Lost & Found Tracker, Household Guardian Hub, Veterinary Care, and Neighborhood Pet Shops & Spas)—into a cohesive, warm modern pet-tech visual language.
- **Target Audience**: Community pet parents, veterinary clinics, rescue volunteers, and neighborhood animal welfare organizers seeking an approachable, trustworthy, and modern care platform.
- **Key Value**: Replaces legacy cold blue and harsh yellow accents with warm earthy tones and soothing organic mints, dramatically improving visual comfort and brand credibility while preserving 100% of existing user data and offline capabilities.

---

## 2. User Experience & Visual Design

### Design System Color Tokens (`:root`)

```css
:root {
  /* Typography */
  --font-body: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
  --font-display: 'Outfit', system-ui, -apple-system, sans-serif;

  /* Surfaces & Canvas */
  --bg-base: #FAF7F2;          /* Warm Cream Canvas */
  --bg-surface: #FFFFFF;       /* Pure White Cards */
  --bg-surface-alt: #F4EFEB;   /* Warm Stone Tint for Secondary Containers */
  --border-subtle: #E8E2D9;    /* Soft Neutral Hairline Borders */
  --border-focus: #E05A47;     /* Terracotta Focus Indicator */

  /* Text & Contrast Hierarchy (No Pure Black) */
  --text-main: #1E293B;        /* Dark Slate Grey */
  --text-muted: #64748B;       /* Refined Slate Muted */
  --text-light: #94A3B8;       /* Subtle Metadata Text */

  /* Primary Brand: Terracotta / Warm Coral */
  --brand-primary: #E05A47;
  --brand-primary-hover: #C84B3A;
  --brand-accent: #EE6C4D;
  --brand-accent-soft: #FDEEE9;

  /* Secondary & Trust: Forest Mint / Sage Green */
  --brand-emerald: #2D6A4F;
  --brand-emerald-bright: #52B788;
  --brand-emerald-soft: #E8F5EE;

  /* Semantic Alerts */
  --brand-rose: #D93844;
  --brand-indigo: #4A5568;

  /* Elevation */
  --card-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
  --card-shadow-hover: 0 16px 35px rgba(224, 90, 71, 0.08);
}
```

### 6 Module Hero Banners

Each hero banner will feature a soft, refined linear gradient that blends warm coral and sage mint pastel hues:

1. **Module 1 (Pet Registration)**:
   - Gradient: `linear-gradient(135deg, #FFF4F0 0%, #FAF0E6 50%, #F0F7F4 100%)`
   - Border: `#F4D3C9`
   - Badge: `#FDE8E1` text `#A83827`
2. **Module 2 (Stray Guardian Network)**:
   - Gradient: `linear-gradient(135deg, #F0F7F4 0%, #F8FAF8 50%, #FFF3EE 100%)`
   - Border: `#C6E2D5`
   - Badge: `#E1F2EA` text `#1E4E38`
3. **Module 3 (Rescue Task Force & Leaderboard)**:
   - Gradient: `linear-gradient(135deg, #FDF7EE 0%, #FFF0EB 50%, #F1F8F4 100%)`
   - Border: `#EAD5C8`
   - Badge: `#FDEEE9` text `#9C3B2D`
4. **Module 4 (Household Guardian Profile)**:
   - Gradient: `linear-gradient(135deg, #FAF3EB 0%, #FFF5F1 50%, #EEF6F2 100%)`
   - Border: `#E8DACF`
   - Badge: `#F6ECE4` text `#784435`
5. **Module 5 (Veterinary Clinic Network)**:
   - Gradient: `linear-gradient(135deg, #EFF8F3 0%, #F4FAF6 50%, #FAF6EE 100%)`
   - Border: `#BFE0CF`
   - Badge: `#DCF2E6` text `#1E5E3D`
6. **Module 6 (Pet Stores & Spa Wellness)**:
   - Gradient: `linear-gradient(135deg, #FFF2EC 0%, #FDF6EE 50%, #F2F8F4 100%)`
   - Border: `#F6D5C7`
   - Badge: `#E05A47` text `#FFFFFF`

### Rescuer Leaderboard Badge Palette
- **Master (👑)**: Royal Terracotta Glow (`background: #FAF0EE; color: #A83827; border: 1px solid #F0C4B8;`)
- **Diamond (💎)**: Forest Mint Gem (`background: #EAF6F0; color: #1E5E3D; border: 1px solid #BFE0CF;`)
- **Elite (⭐)**: Warm Amber Coral (`background: #FDF4EB; color: #B45309; border: 1px solid #FCD34D;`)
- **Beginner (🌱)**: Sage Spring (`background: #F1F8F4; color: #2D6A4F; border: 1px solid #D1E7DD;`)

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: CSS Scoped Update without HTML DOM Changes**
  - *Chosen Approach*: Rewrite the `<style>` block in `index.html` to target existing classes, and adjust inline styles on the 6 hero banners.
  - *Why*: Guarantees zero regressions in event listeners, form binding, validation, or DOM selectors.
- **Decision 2: Retention of Tabular Numerals & High Contrast**
  - *Why*: While introducing warm cream and terracotta tones, all metric counters and phone numbers retain `tabular-nums` and dark slate `#1E293B` to maintain accessibility (WCAG AA 4.5:1+ contrast).

---

## 4. Technical Architecture & File Updates

```
index.html
 ├── <head>
 │    ├── [PRESERVED] Inline LocalStorage & IndexedDB Engine (Zero modification)
 │    └── <style>
 │         ├── :root tokens updated (Terracotta, Forest Mint, Warm Cream, Dark Slate)
 │         ├── Global buttons, active tabs, inputs, focus states updated
 │         ├── Soft 10px-25px shadows on cards and modals
 │         └── Badge, pill, and status color adjustments
 ├── <body>
 │    ├── Header & Live Stat Bar (Color updates via CSS)
 │    ├── Module 1–6 Hero Banners (Soft Warm Coral & Mint pastel gradients)
 │    └── [PRESERVED] All interactive form inputs, modals, and JavaScript functions
```

### Verification & Testing Plan
1. **Visual Consistency Check**: Review all 6 modules to ensure buttons, active nav pills, card shadows, and form borders reflect `#E05A47` and `#2D6A4F`.
2. **Text Contrast Audit**: Verify all headings and body copy use `#1E293B` and `#64748B`, with no pure black `#000000`.
3. **Storage & Functionality Integrity**: Confirm pet registration, stray tagging, lost & found submissions, vet searches, and store additions continue functioning flawlessly.
4. **Compilation Verification**: Run `npm run build` and `compile_applet` to ensure zero compilation or build issues.
